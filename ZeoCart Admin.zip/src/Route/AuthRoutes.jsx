
import ErrorPage4 from '../Components/Pages/ErrorPages/ErrorPage404';

export const authRoutes = [

  //Error
  { path: `/*`, Component: <ErrorPage4 /> },
];
