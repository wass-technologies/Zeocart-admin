export const LaptopcoverCatId = 'd3482b8a-ea64-4aed-8a59-c450f43fac1c';
export const watchCategoryId ='ca3e38c7-d553-4191-916d-9afae2f507f1';
export const headphoneCategoryId = '7892746a-f413-41bb-81d6-0eb885c013be';  
export const phoneGlassCategoryId = '408cf03a-1929-4505-9fa5-b4ce0914a29f';
// export const phoneCoverCategoryId = '12957f8f-0c83-4aa0-857a-72f1dd51df28';
export const phoneCoverCategoryId = 'f82c84db-5e1b-4191-8ee8-25f3f143d3b7';


 