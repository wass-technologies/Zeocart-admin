
export const ReturnLogin =()=>{
    window.location.href ='https://admin.zeocart.com/login'
}